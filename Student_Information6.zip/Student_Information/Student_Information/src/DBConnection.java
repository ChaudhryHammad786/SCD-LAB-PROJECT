
import java.sql.Connection;
import java.sql.DriverManager;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dell
 */
public class DBConnection {
    
    static Connection con=null;
    
    private DBConnection(){
        
    }
     public static Connection getDBConnection(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
             con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student_information","root","");
        }
        catch(Exception e){
            System.out.println(e.getMessage()); 
        }
        return con;
    }
}
