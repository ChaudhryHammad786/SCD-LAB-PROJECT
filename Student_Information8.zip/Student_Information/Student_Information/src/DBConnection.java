
import java.sql.Connection;
import java.sql.DriverManager;





public class DBConnection {
    
    static Connection con=null;
    
    private DBConnection(){
        
    }
     public static Connection getDBConnection(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
             con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student_information","root","");
        }
        catch(Exception e){
            System.out.println(e.getMessage()); 
        }
        return con;
    }
}
