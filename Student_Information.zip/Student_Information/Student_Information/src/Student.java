
import java.util.Date;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dell
 */
public class Student {
    String Name;
    String FatherName;
    String Email;
    String Password;
    String Conatactno;
     Date dob;
     char gender;

    public Student(String Name, String FatherName, String Email, String Password, String Conatactno, Date dob, char gender) {
        this.Name = Name;
        this.FatherName = FatherName;
        this.Email = Email;
        this.Password = Password;
        this.Conatactno = Conatactno;
        this.dob = dob;
        this.gender = gender;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getFatherName() {
        return FatherName;
    }

    public void setFatherName(String FatherName) {
        this.FatherName = FatherName;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public String getConatactno() {
        return Conatactno;
    }

    public void setConatactno(String Conatactno) {
        this.Conatactno = Conatactno;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public char getGender() {
        return gender;
    }

    public void setGender(char gender) {
        this.gender = gender;
    }
     
     
}
